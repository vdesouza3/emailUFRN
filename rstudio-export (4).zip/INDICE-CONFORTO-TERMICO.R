###INDICE TEMPERATURA E UMIDADE
#PACOTES NECESSÁRIOS
library(ggplot2)
library(dplyr)

#LEITURA DO BANCO DE DADOS
dados <- (natal)
summary(dados)
temperatura <- (dados$temperatura)
umidade <- (dados$umidade)
vento <- (dados$vento)

###CÁLCULO DO ITU SEGUNDO THON (1958)
ITU <- (0.8*temperatura + umidade *(temperatura-14.3)/100+46.3)
#CÁLCULO DO THI SEGUNDO THOM (1959)
IDT <- (temperatura-(0.55-0.0055*umidade)*(temperatura-14.5))
#CÁLCULO DO TEV
TEV <- 37-((37-temperatura)/(0.68-(0.0014*umidade)+(1/(1.76+1.4*vento^0.75))))-(0.29*temperatura*(1-(umidade/100)))

#ÍNDICES TEMPERATURA UMIDADE CALCULADOS
print(ITU) 
print(IDT)
print(TEV)

#médias horárias
temperatura_media_horaria <- aggregate(temperatura ~ HORA, FUN = mean, dados)
umidade_media_horaria <- aggregate(umidade ~ HORA, FUN = mean, dados)
vento_media_horaria <- aggregate(vento ~ HORA, FUN = mean, dados)
ITU_medio <- aggregate(ITU ~ HORA, FUN = mean, dados)
IDT_medio <- aggregate(IDT ~ HORA, FUN = mean, dados)
TEV_medio <- aggregate(TEV ~ HORA, FUN = mean, dados)
ITU_medio
IDT_medio
TEV_medio

#plot(TEV_medio, type = "l")
#plot(THI_medio, type = "l")

ggplot(ITU_medio, aes(x=HORA, y=ITU)) + 
  geom_point(color = "yellow") + 
  labs(x="Horário", y="Índice de temperatura e umidade", title="ITU horário médio para Natal (2019)")

ggplot(IDT_medio, aes(x=HORA, y=IDT)) + 
  geom_point(color = "blue") + 
  labs(x="Horário", y="Temperature Humidity Index", title="IDT para Natal (2019)", fill = "blue")

ggplot(TEV_medio, aes(x=HORA, y=TEV)) + 
  geom_point(color = "black") + 
  labs(x="Horário", y="Índice de temperatura efetiva em função do vento", title="TEV para Natal (2019)", fill = "black")

ggplot(temperatura_media_horaria, aes(x=HORA, y=temperatura)) + 
  geom_point(color = "red") + 
  labs(x="Horário", y="Temperatura média (°C)", title="Temperatura horária média de Natal (2019)")

ggplot(umidade_media_horaria, aes(x=HORA, y=umidade)) + 
  geom_point(color = "darkblue") + 
  labs(x="Horário", y="Umidade relativa do ar(%)", title="Umidade horária média de Natal (2019)")

ggplot(vento_media_horaria, aes(x=HORA, y=vento)) + 
  geom_point(color = "darkgray") + 
  labs(x="Horário", y="Velocidade do vento(m/s)", title="Velocidade do vento horária média de Natal (2019)")

###para classificar todos os índices
#CLASSIFICANDO ÍNDICES ITU
indices_class <- c(ITU)  
classificar_indice <- function(valor) {
  if (valor < 5.9) {
    return("RESFRIAMENTO MUITO ELEVADO")
  } else if (valor > 6 & valor <= 8.99999) {
    return("RESFRIAMENTO ELEVADO")
  } else if (valor > 9 & valor <= 11.999999) {
    return("FRIO")
  } else if (valor > 12 & valor <= 14.99999) {
    return("DESCONFORTO PELO FRIO")
  } else if (valor > 15 & valor <= 17.99999) {
    return("LEVE DESCONFORTO POR FRIO")
  } else if (valor > 18 & valor <= 20.99999) {
    return("LIMITE INFERIOR DA ZONA DE CONFORTO")
  } else if (valor > 21 & valor <= 23.99999) {
    return("CENTRO DA ZONA DE CONFORTO")
  } else if (valor > 24 & valor <= 26.99999) {
    return("LIMITE SUPERIOR DA ZONA DE CONFORTO")
  } else if (valor > 27 & valor <= 29.99999) {
    return("LEVE DESCONFORTO PELO CALOR")
  } else if (valor > 30 & valor <= 32.99999) {
    return("DESCONFORTO PELO CALOR")
  } else if (valor >= 33) {
    return("AQUECIMENTO ELEVADO")
  }
}

indicesitu <- sapply(ITU, classificar_indice)
print(indicesitu)

#CLASSIFICANDO ÍNDICES IDT
indices_class <- c(IDT)  
classificar_indice <- function(valor) {
  if (valor < 5.9) {
    return("RESFRIAMENTO MUITO ELEVADO")
  } else if (valor > 6 & valor <= 8.99999) {
    return("RESFRIAMENTO ELEVADO")
  } else if (valor > 9 & valor <= 11.999999) {
    return("FRIO")
  } else if (valor > 12 & valor <= 14.99999) {
    return("DESCONFORTO PELO FRIO")
  } else if (valor > 15 & valor <= 17.99999) {
    return("LEVE DESCONFORTO POR FRIO")
  } else if (valor > 18 & valor <= 20.99999) {
    return("LIMITE INFERIOR DA ZONA DE CONFORTO")
  } else if (valor > 21 & valor <= 23.99999) {
    return("CENTRO DA ZONA DE CONFORTO")
  } else if (valor > 24 & valor <= 26.99999) {
    return("LIMITE SUPERIOR DA ZONA DE CONFORTO")
  } else if (valor > 27 & valor <= 29.99999) {
    return("LEVE DESCONFORTO PELO CALOR")
  } else if (valor > 30 & valor <= 32.99999) {
    return("DESCONFORTO PELO CALOR")
  } else if (valor >= 33) {
    return("AQUECIMENTO ELEVADO")
  }
}

indicesidt <- sapply(IDT, classificar_indice)
print(indicesidt)

#CLASSIFICANDO ÍNDICES TEV
indices_class <- c(TEV)  

classificar_indice <- function(valor) {
  if (valor < 5) {
    return("EXTREMO ESTRESSE AO FRIO")
  } else if (valor > 10 & valor <= 13) {
    return("TIRITAR")
  } else if (valor > 13 & valor <= 16) {
    return("RESFRIAMENTO DO CORPO")
  } else if (valor > 16 & valor <= 19) {
    return("LIGEIRO RESFRIAMENTO DO CORPO")
  } else if (valor > 19 & valor <= 22) {
    return("VASOCONSTRIÇÃO")
  } else if (valor > 22 & valor <= 25) {
    return("NEUTRALIDADE TÉRMICA")
  } else if (valor > 25 & valor <= 28) {
    return("LIGEIRO SUOR, VASODILATAÇÃO")
  } else if (valor > 28 & valor <= 31) {
    return("SUANDO")
  } else if (valor > 31 & valor <= 34) {
    return("SUOR EM PROFUSÃO")
  } else if (valor >= 34) {
    return("FALHA NA TERMOREGULAÇÃO")
  }
}

indicestev <- sapply(TEV, classificar_indice)
print(indicestev)

#SALVANDO EM TXT
write.table(indices, file = "C:/Users/itaua/OneDrive/METCLIM/CONFORTO TÉRMICO HUMANO NATAL/natalthiclass.txt", quote = TRUE, sep = "",
            eol = "\n", na = "NA", dec = ",", row.names = FALSE,
            col.names = FALSE, qmethod = c("escape", "double"),
            fileEncoding = "")


# Salvando o objeto em um arquivo de texto
write(as.character(indices), file = "C:/Users/itaua/OneDrive/METCLIM/CONFORTO TÉRMICO HUMANO NATAL/natalthiclass.txt")
